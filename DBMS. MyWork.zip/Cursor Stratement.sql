--STEP 1
DECLARE c1 CURSOR FOR <select-query>

---STEP 2
OPEN c1

--- STEP 3
FETCH NEXT FROM  c1
INTO <variables-sorresponding -to-columns-in-select-query>

---STEP 4
---Your Logic
---Use conditions,loops,Queries

---STEP 5
CLOSE c1


---STEP 6
DEALLOCATE c1


---------INCREMENT FOR WORKERS----


DECLARE @EmpId INT,@EmpName NVARCHAR(50), @ManagerId INT, @Doj AS DATETIME


DECLARE c1 CURSOR  FOR
SELECT EmpId,EmpName, ManagerId ,Doj FROM EmployeeTable
WHERE IsActive=1

OPEN c1
FETCH NEXT FROM c1
INTO @EmpId, @EmpName,@ManagerId,@Doj
PRINT 'IN Cursor'


WHILE @@FETCH_STATUS = 0
BEGIN
	IF @Doj > '01/01/2022' AND @Doj < '12/31/2023'
		PRINT 'Increment for '+ @EmpName + ': 10%'
	ELSE IF @Doj BETWEEN '01/01/2023'  AND '12/31/2023'
		PRINT 'Not eligible for Increment'
	ELSE IF @Doj BETWEEN '01/01/2021' AND'12/31/2023'
		PRINT 'Increment for '+ @EmpName + ': 20%'
	ELSE IF @Doj <'01/01/2021'
		PRINT 'Increment for' + @EmpName +': 30%'

FETCH NEXT FROM c1 INTO @EmpId, @EmpName, @ManagerId, @doj
END

CLOSE c1
DEALLOCATE c1



-------------------------BOILER PLATING----------------------

--------require statement, Return cimma separated employee names------
--------Analysis: SQL Feature: Cursor, coz record-by-record processing----


CREATE FUNCTION fnEmpToCsv() RETURNS NVARCHAR(MAX)
AS
BEGIN
	DECLARE @EmpName nvarchar(max), @result nvarchar(max)

	DECLARE c1 CURSOR for 
	SELECT EmpName from EmployeeTable
	OPEN c1
	FETCH NEXT  FROM c1
		INTO @EmpName

	--LOGIC
	SET @result =''
	WHILE @@FETCH_STATUS = 0
	BEGIN

		SET @result = @result + ' ' +@EmpName +' , '
		FETCH NEXT FROM c1
			INTO @EmpName
	END


	CLOSE c1
	DEALLOCATE c1
	RETURN @result
END

GO
SELECT dbo.fnEmpToCsv()


