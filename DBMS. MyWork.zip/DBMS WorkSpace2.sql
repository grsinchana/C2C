-- Microlab--

-- Anme with EmpId--

SELECT EmpName + '-' + CAST(EmpId as nVarchar) as [FORMAT] FROM EmployeeTable


---- -- --- - -  -- -
SELECT (SELECT EmpName from EmployeeTable where EmpId=1001) as [Employee Name],
		(SELECT 5+5) as [Percent Hike]

		-----------------------------

SELECT* FROM EmployeeTable WHERE EmpName LIKE 'S%'
-- --

SELECT* FROM EmployeeTable WHERE EmpName LIKE '%A'

-- --

SELECT* FROM EmployeeTable WHERE EmpName LIKE '% %'
-- --

SELECT* FROM EmployeeTable WHERE EmpName LIKE '_a%'

----------------------------------------------------------

--1---
SELECT * From TasksTable WHERE Name LIKE '%coding%'

--2-
SELECT * from TasksTable WHERE Enddate <=' 2023-10-30' 

--3--
SELECT * from TasksTable WHERE Startdate = ' 2023-10-25'

--4--

SELECT Name + '  -  ' + '  starts on  ' + '  -  ' + CAST(Startdate as nVarchar) + ' - ' +   '  Ends on  ' + '-' + CAST(Enddate as nVarchar) as [DATES] FROM TasksTable


SELECT EmpName + '-' + CAST(EmpId as nVarchar) as [FORMAT] FROM EmployeeTable

--- CREATE A QUICK BACKUP TABLE(REPLICA)--_{ ONE LINER CODE}
SELECT * INTO Employeebackup from EmployeeTable WHERE ManagerID IS NOT NULL(specifies that we dont need manager ID column)