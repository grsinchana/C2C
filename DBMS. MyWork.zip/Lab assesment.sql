----1-----

SELECT InstName, COUNT(StuId) AS number_of_students FROM Institute INNER JOIN StuTable ON StuTable.InstId=Institute.InstId GROUP BY InstName

-----2-----


----3-----



