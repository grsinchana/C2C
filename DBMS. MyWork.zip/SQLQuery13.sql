USE [trial]
GO
/****** Object:  UserDefinedFunction [dbo].[fnEmpToCsv]    Script Date: 30-10-2023 12:36:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[fnEmpToCsv]() RETURNS NVARCHAR(MAX)
AS
BEGIN
	DECLARE @EmpName nvarchar(max), @result nvarchar(max)

	DECLARE c1 CURSOR for 
	SELECT EmpName from EmployeeTable
	OPEN c1
	FETCH NEXT  FROM c1
		INTO @EmpName

	--LOGIC
	SET @result =''
	WHILE @@FETCH_STATUS = 0
	BEGIN

		SET @result = @result + @EmpName +','
		FETCH NEXT FROM c1
			INTO @EmpName
	END


	CLOSE c1
	DEALLOCATE c1
	RETURN @result
END
GO
/****** Object:  Table [dbo].[EmployeeTable]    Script Date: 30-10-2023 12:36:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmployeeTable](
	[EmpId] [int] IDENTITY(1000,1) NOT NULL,
	[EmpName] [nvarchar](50) NULL,
	[ManagerId] [int] NULL,
	[EmailId] [nvarchar](70) NULL,
	[Doj] [datetime] NULL,
	[IsActive] [bit] NULL,
 CONSTRAINT [PK_EmployeeTable] PRIMARY KEY CLUSTERED 
(
	[EmpId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TasksTable]    Script Date: 30-10-2023 12:36:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TasksTable](
	[TaskId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](200) NULL,
	[Startdate] [datetime] NULL,
	[Enddate] [datetime] NULL,
 CONSTRAINT [PK_TasksTable] PRIMARY KEY CLUSTERED 
(
	[TaskId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EmpTask]    Script Date: 30-10-2023 12:36:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmpTask](
	[EmpId] [int] NOT NULL,
	[TaskId] [int] NOT NULL,
	[IsSubmitted] [bit] NOT NULL,
	[IsCompleted] [bit] NOT NULL,
	[ModifiedOn] [datetime] NOT NULL,
 CONSTRAINT [PK_EmpTask] PRIMARY KEY CLUSTERED 
(
	[EmpId] ASC,
	[TaskId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_EmpTaskNames]    Script Date: 30-10-2023 12:36:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_EmpTaskNames] AS 
SELECT E.EmpName,T.[Name] FROM EmployeeTable as E LEFT OUTER JOIN EmpTask as ET ON E.EmpId= ET.EmpId LEFT OUTER JOIN TasksTable as T ON T.TaskId =ET.TaskId
GO
/****** Object:  View [dbo].[vw_EmpCount]    Script Date: 30-10-2023 12:36:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_EmpCount] AS
SELECT E.EmpName, COUNT (T.[Name]) as TaskCount FROM EmployeeTable as E LEFT OUTER JOIN EmpTask as ET ON E.EmpId = ET.empId
	LEFT OUTER JOIN TasksTable as T ON T.TaskId= ET.TaskId GROUP BY E.EmpName
GO
/****** Object:  Table [dbo].[Employeebackup]    Script Date: 30-10-2023 12:36:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Employeebackup](
	[EmpId] [int] IDENTITY(1000,1) NOT NULL,
	[EmpName] [nvarchar](50) NULL,
	[ManagerId] [int] NULL,
	[EmailId] [nvarchar](70) NULL,
	[Doj] [datetime] NULL,
	[IsActive] [bit] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EmpTaskBackup]    Script Date: 30-10-2023 12:36:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmpTaskBackup](
	[EmpId] [int] NOT NULL,
	[TaskId] [int] NOT NULL,
	[IsSubmitted] [bit] NOT NULL,
	[IsCompleted] [bit] NOT NULL,
	[ModifiedOn] [datetime] NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[EmpTask]  WITH CHECK ADD  CONSTRAINT [FK_EmpTask_EmployeeTable] FOREIGN KEY([EmpId])
REFERENCES [dbo].[EmployeeTable] ([EmpId])
GO
ALTER TABLE [dbo].[EmpTask] CHECK CONSTRAINT [FK_EmpTask_EmployeeTable]
GO
ALTER TABLE [dbo].[EmpTask]  WITH CHECK ADD  CONSTRAINT [FK_EmpTask_TasksTable] FOREIGN KEY([TaskId])
REFERENCES [dbo].[TasksTable] ([TaskId])
GO
ALTER TABLE [dbo].[EmpTask] CHECK CONSTRAINT [FK_EmpTask_TasksTable]
GO
/****** Object:  StoredProcedure [dbo].[sp_del]    Script Date: 30-10-2023 12:36:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_del] AS
DELETE FROM EmpTask where EmpId=1000
GO
/****** Object:  StoredProcedure [dbo].[sp_EmpTasks]    Script Date: 30-10-2023 12:36:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_EmpTasks] AS
SELECT T.Name,E.EmpId FROM  EmpTask as ET INNER JOIN TasksTable as T ON  ET.TaskId=T.TaskId INNER JOIN EmployeeTable as E ON   E.EmpId=ET.EmpId
GO
/****** Object:  StoredProcedure [dbo].[sp_GetEmpTasNames]    Script Date: 30-10-2023 12:36:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_GetEmpTasNames] AS 
SELECT E.EmpName,T.[Name] FROM EmployeeTable as E LEFT OUTER JOIN EmpTask as ET ON E.EmpId= ET.EmpId LEFT OUTER JOIN TasksTable as T ON T.TaskId =ET.TaskId
GO
/****** Object:  StoredProcedure [dbo].[sp_inse]    Script Date: 30-10-2023 12:36:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_inse] AS
INSERT INTO EmpTask
values ('1002','4','True','True','12/10/2023')
GO
/****** Object:  StoredProcedure [dbo].[sp_InsEmp]    Script Date: 30-10-2023 12:36:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_InsEmp] AS
SELECT T.Name,T.EndDate,COUNT(T.TaskId) as TaskCount FROM TasksTable as T
GROUP BY T.EndDate,T.Name
GO
/****** Object:  StoredProcedure [dbo].[sp_inser]    Script Date: 30-10-2023 12:36:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_inser] AS
INSERT INTO EmpTask
values ('1001','2','True','True','12/10/2023')
GO
/****** Object:  StoredProcedure [dbo].[sp_insert]    Script Date: 30-10-2023 12:36:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_insert] AS
INSERT INTO EmpTask
SELECT '1001','2','True','True','12/10/2023'
GO
/****** Object:  StoredProcedure [dbo].[sp_updatetask]    Script Date: 30-10-2023 12:36:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[sp_updatetask] AS
UPDATE TasksTable SET [StartDate] = '2023-04-14',[EndDate]='2023-04-14'
WHERE taskId=5
GO
/****** Object:  StoredProcedure [dbo].[vr_EmpCount]    Script Date: 30-10-2023 12:36:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[vr_EmpCount] AS
SELECT E.EmpName, COUNT (T.[Name]) as TaskCount FROM EmployeeTable as E LEFT OUTER JOIN EmpTask as ET ON E.EmpId = ET.empId
	LEFT OUTER JOIN TasksTable as T ON T.TaskId= ET.TaskId GROUP BY E.EmpName
GO
