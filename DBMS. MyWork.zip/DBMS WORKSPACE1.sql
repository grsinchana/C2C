
-- --
select * from EmployeeTable

select 'Without using from clause' as [Message],
		'1001' as [Code Number],
		'HA HA HA' as Comments
-- --
DECLARE @varName NVARCHAR(50)
SET @varName = 'A NEW VALUE'
-- --
SELECT @varName as [Using Variables]
-- --
DECLARE @var2 INT
SET @var2 = 1001
-- --
SELECT @var2 = 1002

-- --
SELECT TOP 2 EmpId, EmpName FROM EmployeeTable
-- --
SELECT * from EmployeeTable ORDER BY EmpName ASC
-- --
SELECT TOP 1 * FROM EmployeeTable ORDER BY EmpId DESC
-- --
SELECT * From EmployeeTable ORDER BY EmpId DESC
-- --

SELECT 'where to go ' as [Trip],
		'Hampi' as [Area],
		'20 Days' as [ Duration]
-- --
SELECT DISTINCT EmpId,EmpName from EmployeeTable
-- --

SELECT DISTINCT EmpName FROM EmployeeTable
-- --

SELECT * FROM EmployeeTable WHERE EmpName ='Sinchana' AND EmpId= '1000'
-- --

SELECT * FROM EmployeeTable where EmpName NOT IN ('Sinchana', 'Neha')
-- --

SELECT * FROM EmployeeTable where EmpName IN ('Sinchana', 'Neha')
-- --

SELECT * FROM EmployeeTable WHERE EmpId BETWEEN 1000 AND 1002
-- --

SELECT * FROM EmployeeTable WHERE Doj BETWEEN '2023-10-01 00:00:000' AND '2023-10-31 00:00:000'

-- --

SELECT DISTINCT  EmpName FROM EmployeeTable WHERE Doj BETWEEN '2023-10-01 00:00:000' AND '2023-10-31 00:00:000'
-- --

SELECT * FROM EmployeeTable WHERE Doj BETWEEN '2023-10-01 00:00:000' AND '2023-10-31 00:00:000'
-- --

SELECT* FROM EmployeeTable WHERE EmpName LIKE 'S%'
-- --

SELECT* FROM EmployeeTable WHERE EmpName LIKE '%A'

-- --

SELECT* FROM EmployeeTable WHERE EmpName LIKE '% %'
-- --

SELECT* FROM EmployeeTable WHERE EmpName LIKE '_a%'

-- --

SELECT (SELECT EmpName from EmployeeTable where EmpId=1001) as [Employee Name],
		(SELECT 5+5) as [Percent Hike]

-- Select statements to assign a value for a variable
Declare @EmpId INT
SET @EmpId = (SELECT Top 1 EmpId FROM EmployeeTable Where EmpName ='Sinchana')
SELECT @EmpId as [EmpId assigned To Variable]

-- Select statements to assign & print value of a variable--

Declare @newValue INT
SELECT @newValue =(SELECT Top 1 EmpId From EmployeeTable where EmpName='Sinchana')
SELECT @newValue

PRINT 'THE FINAL VALUE OF THE VARIABLE @newValue =' + CAST(@newValue AS nVarchar)


-- --

Declare @newValue INT
SELECT @newValue =(SELECT Top 1 EmpId From EmployeeTable where EmpName='Sinchana')
SELECT @newValue
-- --
-- Anme with EmpId--

SELECT EmpName + '-' + CAST(EmpId as nVarchar) as [FORMAT] FROM EmployeeTable

-- MICROLAB--
--Geth task name with their matching EmpIds--

SELECT T.Name, ET.EmpId FROM TasksTable as T INNER JOIN EmpTask as ET on T.TaskId = ET.TaskId


-- Get EmpName with their corresponding Tasknames--

SELECT *FROM EmployeeTable as E INNER JOIN EmpTask as ET ON E.EmpId=ET.EmpId INNER JOIN TasksTable as T ON T.TaskId = ET.TaskId

--////////////////////////////--

SELECT EmployeeTable as [Employee Name], T.[Name] as [Working on Task] FROM EmployeeTable as E INNER JOIN EmpTask as ET 
        ON E.EmpId=ET.EmpId INNER JOIN TasksTable as T 
        ON T.TaskId=ET.TaskId (INCORRECT)



-- GET TASKNAMES ASSIGNED TO ALL EMPIDS--------------

SELECT * FROM TasksTable as T LEFT OUTER JOIN EmpTask as ET ON T.TaskId = ET.TaskId

----------------------------------------------------

SELECT * INTO EmpTaskBackup from EmpTask

-- TaskIds for All EmmNmaes
SELECT E.[EmpName], ET.TaskId FROM EmployeeTable as E LEFT OUTER JOIN EmpTask as ET ON E.EmpId=ET.EmpId

--RIGHT OUTER JOIN__

SELECT E.[EmpName],ET.TaskId FROM EmpTask as ET RIGHT OUTER JOIN EmployeeTable as E ON ET.EmpId =E.EmpId

-------FULL JOIN-----------------

SELECT E.EmpName, ET.TaskId FROM EmployeeTable as E FULL OUTER JOIN EmpTaskBackup as ET ON E.EmpId= ET.EmpId


--CREATE VIEW----

CREATE VIEW vw_EmpTaskNames AS 
SELECT E.EmpName,T.[Name] FROM EmployeeTable as E LEFT OUTER JOIN EmpTask as ET ON E.EmpId= ET.EmpId LEFT OUTER JOIN TasksTable as T ON T.TaskId =ET.TaskId


--CREATE STORED PROCEDURE---

CREATE PROCEDURE sp_GetEmpTasNames AS 
SELECT E.EmpName,T.[Name] FROM EmployeeTable as E LEFT OUTER JOIN EmpTask as ET ON E.EmpId= ET.EmpId LEFT OUTER JOIN TasksTable as T ON T.TaskId =ET.TaskId


--FOR executing stored procedure---
exec sp_GetEmpTasNames


--Alter procedure--------------


ALTER PROCEDURE sp_GetEmpTasKNamesForeEmployee @EmpName NVARCHAR(50) AS  
SELECT E.EmpName,T.[Name] FROM EmployeeTable as E LEFT OUTER JOIN EmpTask as ET ON E.EmpId = ET.EmpId LEFT OUTER JOIN TasksTable as T ON T.TaskId =ET.TaskId
WHERE E.EmpName = @EmpName AND T.[NAME] IS NOT NULL


-------------------------------------------------------------------------

CREATE FUNCTION fn_GetTaskNamesForEmployee (@EmpName nVarchar(50)
RETURNS nVarchar(50)
AS
BEGIN
		RETURNS (SELECT COUNT T.[Name] FROM EmployeeTable AS E LEFT OUTER JOIN EmpTask as ET ON E.EmpId =ET.EmpId LEFT OUTER JOIN Task as T 
		ON T.TaskId WHERE E.EmpName=@EmpName 
		AND T.[Name] IS NOT NULL



------------------------------------------------------------

SELECT E.EmpName, COUNT (T.[Name]) as TaskCount FROM EmployeeTable as E LEFT OUTER JOIN EmpTask as ET ON E.EmpId = ET.empId
	LEFT OUTER JOIN TasksTable as T ON T.TaskId= ET.TaskId GROUP BY E.EmpName


CREATE PROCEDURE vr_EmpCount AS
SELECT E.EmpName, COUNT (T.[Name]) as TaskCount FROM EmployeeTable as E LEFT OUTER JOIN EmpTask as ET ON E.EmpId = ET.empId
	LEFT OUTER JOIN TasksTable as T ON T.TaskId= ET.TaskId GROUP BY E.EmpName

CREATE VIEW vw_EmpCount AS
SELECT E.EmpName, COUNT (T.[Name]) as TaskCount FROM EmployeeTable as E LEFT OUTER JOIN EmpTask as ET ON E.EmpId = ET.empId
	LEFT OUTER JOIN TasksTable as T ON T.TaskId= ET.TaskId GROUP BY E.EmpName


	-----------------------------------

INSERT INTO TasksTable VALUES ('Coding','10/25/2023','10/30/2023')
 


 ----------INSERTION IN BULK------------------
INSERT INTO TasksTable
SELECT 'Coding','03/10/2023','12/11/2023'
UNION ALL
SELECT 'Designing','12/10/2023','1/11/2023'
UNION ALL
SELECT 'Developing','11/10/2023','02/11/2023'


DECLARE @TaskId INT,@counter INT
SET @TaskId=1002
SET @counter =1

WHILE (@TaskId<=1000)
BEGIN 
	UPDATE TaskBackup SET [Name] ='DAY' +CAST(@counter AS nVarchar)+ 'LabWork'
	WHERE TaskId =  @TaskId

	SET @TaskId = @TaskId+1
	SET @counter = @counter+1
END



INSERT INTO TasksTable SELECT [Name],[StartDate],[EndDate] FROM TaskBackup


----------------------------
--Create stored procedures for 
--          Select all tasks for an EmpId
--         Get all tasks grouped by endDate
--         Intert into EmpTasks
--         Update the dates fora given TaskId (params:TaskId,StartDate,Enddate)
--         Delete a task for an employeeId




---1---
CREATE PROCEDURE sp_EmpTasks AS
SELECT T.Name,E.EmpId FROM  EmpTask as ET INNER JOIN TasksTable as T ON  ET.TaskId=T.TaskId INNER JOIN EmployeeTable as E ON   E.EmpId=ET.EmpId


exec sp_EmpTasks


----3----
CREATE PROCEDURE sp_inse AS
INSERT INTO EmpTask
values ('1002','4','True','True','12/10/2023')

exec sp_inse

----2----

CREATE PROCEDURE sp_InsEmp AS
SELECT T.Name,T.EndDate,COUNT(T.TaskId) as TaskCount FROM TasksTable as T
GROUP BY T.EndDate,T.Name


exec sp_InsEmp


----5----

CREATE PROCEDURE sp_del AS
DELETE FROM EmpTask where EmpId=1000

exec sp_del

------4------
CREATE procedure sp_updatetask AS
UPDATE TasksTable SET [StartDate] = '2023-04-14',[EndDate]='2023-04-14'
WHERE taskId=5

exec sp_updatetask


---CURSOR FOR INCREMENT----

