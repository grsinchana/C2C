-- Using SELECT with more than one table--
-- display all employee with their corresponding TaskName--

SELECT *  FROM EmployeeTable as E, TasksTable as T, EmpTask ET w


SELECT E.EmpName, ET.TaskId FROM EmployeeTable as E , EmpTask as ET WHERE E.EmpId =ET.EmpId

SELECT ET.TaskId, T.Name FROM TasksTable as T , EmpTask as ET WHERE T.TaskId = ET.TaskId 

SELECT E.EmpName,ET.TaskId FROM EmployeeTable as E INNER JOIN EmpTask as ET ON E.EmpId=ET.EmpId



----------TRANSACTIONSSSSSSS-----------

BEGIN TRANSACTION
	INSERT INTO TasksTable SELECT 'New Task 1','10/27/2023','12/18/2023'
SAVE TRANSACTION trInsert
	DELETE FROM TasksTable WHERE TaskId= @@Identity
	SELECT*FROM TasksTable
ROLLBACK Transaction trInsert
COMMIT

SELECT * FROM TasksTable